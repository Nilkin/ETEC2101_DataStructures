package piececheck;
/**
 *
 * @author Thoma
 */
public class Pawn implements Piece{
    int Row;
    int Col;
    Pawn(int r, int c){
        this.Row = r;
        this.Col = c;
    }
    @Override
    public int getRow(){
        return this.Row;
    }
    @Override
    public int getCol(){
        return this.Col;
    }
    @Override
    public char getSymbol(){
        return 'P';
    }
    @Override
    public boolean canMoveTo(int r, int c){
        if((r-1)==this.Row && c==this.Col)
            return true ;
        else
            return false;
    }
}
