package piececheck;
public interface Piece {
    int getRow();
    int getCol();
    char getSymbol();
    boolean canMoveTo(int r, int c);
}
