package piececheck;
public class King implements Piece{
    int Row, Col;
    King(int r, int c){
        //set self values
        this.Row = r; this.Col = c;
    }
    @Override
    public int getRow(){
        return this.Row;
    }
    @Override
    public int getCol(){
        return this.Col;
    }
    @Override
    public char getSymbol(){
        return 'K';
    }
    @Override
    public boolean canMoveTo(int r, int c){
        int pr = getRow(); int pc = getCol();
        //is one square up or down
        if(c>(pc+1) || c<(pc-1))
            return false;
        else if(r>(pr+1) || r<(pr-1))
            return false;
        else
            return true;
    }
}
