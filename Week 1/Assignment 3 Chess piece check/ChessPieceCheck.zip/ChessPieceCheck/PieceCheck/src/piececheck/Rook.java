package piececheck;
public class Rook implements Piece {
    int Row, Col;
    Rook(int r, int c){
        //set self values
        this.Row = r; this.Col = c;
    }
    @Override
    public int getRow(){
        return this.Row;
    }
    @Override
    public int getCol(){
        return this.Col;
    }
    @Override
    public char getSymbol(){
        return 'R';
    }
    @Override
    public boolean canMoveTo(int r, int c){
        int pr = getRow(); int pc = getCol();
        //Can move up or down as long as in Col
        if((r>pr || r<pr) && c==pc)
            return true;
        //Can move left or right as long as in Row
        else if(r==pr && (c>pc || c<pc))
            return true;
        //cant move diagonally
        else
            return false;
    }
}
