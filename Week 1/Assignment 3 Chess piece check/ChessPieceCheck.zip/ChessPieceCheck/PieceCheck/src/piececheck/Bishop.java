package piececheck;
public class Bishop implements Piece {
    int Row,Col;
    Bishop(int r, int c){
        this.Row = r; this.Col = c;
    }
    @Override
    public int getRow(){
        return this.Row;
    }
    @Override
    public int getCol(){
        return this.Col;
    }
    @Override
    public char getSymbol(){
        return 'B';
    }
    @Override
    public boolean canMoveTo(int r, int c){
        int pr = getRow(), pc = getCol();
        //both the row and col are same amount of square spaces diagonally from origin
        if((r-pr)==(c-pc) || (r-pr)*(-1)==(c-pc))
            return true;
        else
            return false;
    }
}
